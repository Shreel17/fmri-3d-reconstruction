
from pathlib import Path

import numpy as np
from sklearn.decomposition import PCA
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import StandardScaler

from starter import load_split, save_predictions, export_outputs


def brain_features(data):
    x = data["X"].astype(np.float32)
    temporal_mean = x.mean(axis=1)
    temporal_std = x.std(axis=1)
    return np.concatenate([temporal_mean, temporal_std], axis=1)


def main():
    print("Loading training, validation, and test data...")
    train = load_split("train")
    val = load_split("val")
    test = load_split("test")

    # Combine labeled development data for final test inference.
    x_train = np.concatenate(
        [brain_features(train), brain_features(val)], axis=0
    )
    x_test = brain_features(test)

    all_points = np.concatenate(
        [train["obj_points"], val["obj_points"]], axis=0
    )
    all_groups = np.concatenate([
        train["group"],
        val["group"] + len(train["obj_points"]),
    ])

    print("Scaling features...")
    scaler = StandardScaler()
    x_train = scaler.fit_transform(x_train)
    x_test = scaler.transform(x_test)

    n_components = min(128, x_train.shape[0] - 1, x_train.shape[1])
    pca = PCA(
        n_components=n_components,
        whiten=True,
        svd_solver="randomized",
        random_state=42,
    )

    z_train = pca.fit_transform(x_train)
    z_test = pca.transform(x_test)

    print("Retrieving nearest training shapes...")
    similarities = cosine_similarity(z_test, z_train)
    nearest = similarities.argmax(axis=1)
    object_ids = all_groups[nearest]
    predictions = all_points[object_ids].astype(np.float32)

    out_dir = Path("submission")
    out_dir.mkdir(parents=True, exist_ok=True)

    prediction_path = out_dir / "predictions.npz"
    save_predictions(prediction_path, test["sample_id"], predictions)

    print("Saved predictions:", prediction_path.resolve())
    print("Prediction shape:", predictions.shape)
    print("Unique retrieved objects:", len(np.unique(object_ids)))

    print("Exporting PLY files and camera renders...")
    export_outputs(out_dir, test["sample_id"], predictions)

    print("Test prediction and export completed.")


if __name__ == "__main__":
    main()

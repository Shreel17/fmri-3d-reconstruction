from pathlib import Path

import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import cosine_similarity

from starter import load_split, save_predictions


def brain_features(data):
    x = data["X"].astype(np.float32)
    temporal_mean = x.mean(axis=1)
    temporal_std = x.std(axis=1)
    return np.concatenate([temporal_mean, temporal_std], axis=1)


def main():
    train = load_split("train")
    val = load_split("val")

    x_train = brain_features(train)
    x_val = brain_features(val)

    scaler = StandardScaler()
    x_train = scaler.fit_transform(x_train)
    x_val = scaler.transform(x_val)

    n_components = min(128, x_train.shape[0] - 1, x_train.shape[1])
    pca = PCA(
        n_components=n_components,
        whiten=True,
        svd_solver="randomized",
        random_state=42,
    )
    z_train = pca.fit_transform(x_train)
    z_val = pca.transform(x_val)

    similarities = cosine_similarity(z_val, z_train)
    nearest = similarities.argmax(axis=1)

    predicted_groups = train["group"][nearest]
    predictions = train["obj_points"][predicted_groups].astype(np.float32)

    out = Path("val_predictions_v2.npz")
    save_predictions(out, val["sample_id"], predictions)

    print("Validation scans:", len(val["sample_id"]))
    print("PCA components:", n_components)
    print("Explained variance:", round(float(pca.explained_variance_ratio_.sum()), 4))
    print("Unique retrieved objects:", len(np.unique(predicted_groups)))
    print("Saved:", out.resolve())


if __name__ == "__main__":
    main()
